// This is a generated file. Do not edit. See application-descriptor.xml.
// WLClient configuration variables.
console.log("Running static_app_props.js...");
var WL = WL ? WL : {};
WL.StaticAppProps = { APP_ID: 'com.mfp.hardware',
  APP_VERSION: '1.0.0',
  WORKLIGHT_PLATFORM_VERSION: '8.0.0.00-20200719-153128',
  WORKLIGHT_NATIVE_VERSION: '3529416104',
  LANGUAGE_PREFERENCES: 'en',
  API_PROXY_URL: '/adapters/MobileAPIProxy',
  ENVIRONMENT: 'android',
  WORKLIGHT_ROOT_URL: '/apps/services/api/com.mfp.hardware/android/',
  APP_SERVICES_URL: '/apps/services/',
  APP_DISPLAY_NAME: 'hardware',
  LOGIN_DISPLAY_TYPE: 'embedded',
  mfpClientCustomInit: false,
  MESSAGES_DIR: 'plugins\\cordova-plugin-mfp\\worklight\\messages' };